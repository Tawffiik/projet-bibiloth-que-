#include <stdio.h>
#include<stdlib.h>
#include<string.h>
/*Computer library that will help us to use different useful commands 
*/


typedef struct{
char titre[100];
char auteur[100];
int numero_id;
char cathegorie[100];
}Livre;
/*this structure is used to add books with precision*/


typedef struct{
char login[100];
char mdp[100];
char role[100];
}Utilisateur;
/* This structure is used to add a student or a professor with their login and password*/

int main() {//the main program

  Livre livre1;
  Livre livre2;
  Livre livre3;
  Livre livre4;
  Livre livre5;

  
  strcpy(livre1.titre, "L'étranger");
  strcpy(livre1.auteur, "Albert Camus");
  livre1.numero_id= 2034;
  strcpy(livre1.cathegorie, "Roman, Fiction");

  strcpy(livre2.titre, "Candide ou l'Optimisme");
  strcpy(livre2.auteur, "Voltaire");
  livre2.numero_id=2035;
  strcpy(livre2.cathegorie, "Roman, Tragédie");


  strcpy(livre3.titre, "Fables");
  strcpy(livre3.auteur, "La Fontaine");
  livre3.numero_id=2036;
  strcpy(livre3.cathegorie, "Fable");

  strcpy(livre4.titre, "Gargantua");
  strcpy(livre4.auteur, "Rabelais");
  livre4.numero_id=2037;
  strcpy(livre4.cathegorie,"Fiction");


  strcpy(livre5.titre, "Roméo et Juliette");
  strcpy(livre5.auteur, "Wiliam Shakespeare");
  livre5.numero_id= 2038;
  strcpy(livre5.cathegorie, "Tragédie");
  //Adding books with their information


  Utilisateur utilisateur1;
  Utilisateur utilisateur2;
  Utilisateur utilisateur3;
  Utilisateur utilisateur4;
  Utilisateur utilisateur5;

  strcpy(utilisateur1.login, "Tawfik95");
  strcpy(utilisateur1.mdp, "TawTaw%");
  strcpy(utilisateur1.role, "Etudiant");


  strcpy(utilisateur2.login, "Jaoued95");
  strcpy(utilisateur2.mdp, "JaJa*");
  strcpy(utilisateur2.role, "Etudiant");

  strcpy(utilisateur3.login, "Leo95");
  strcpy(utilisateur3.mdp, "LeL^");
  strcpy(utilisateur3.role, "Etudiant");

  strcpy(utilisateur4.login, "charif");
  strcpy(utilisateur4.mdp, "Cha!");
  strcpy(utilisateur4.role, "Professeur");


  strcpy(utilisateur5.login, "Mohamed");
  strcpy(utilisateur5.mdp, "Moha'");
  strcpy(utilisateur5.role, "Professeur");
  /*Adding the student or the professors with their information*/



  printf("***********************************\n");
  printf("      Application CY-BiblioTECH    \n");
  printf("***********************************\n\n\n");
  // The name of the application


  char motdepasse[100];
  char identifiant[100];
  int connection;

  printf("1.Se connecter.\n");
  printf("2. Nouvel utilisateur ?\n\n");
  /*To ask if they want to log in or create an account*/

  scanf("%d", &connection);

  switch(connection){

    case 1:
    printf("login\n");
    scanf("%s",identifiant);
 
  
        if(identifiant==utilisateur1.login){  
         printf("password");
    
        }
        else if(identifiant==utilisateur2.login){
          printf("password\n\n");
          scanf("%s",motdepasse);
        }
        else if(identifiant==utilisateur3.login){
          printf("password\n\n");
          scanf("%s",motdepasse);
        }
        else if(identifiant==utilisateur4.login){
          printf("password\n\n");
          scanf("%s",motdepasse);
        }
        else if(identifiant==utilisateur5.login){
          printf("password\n\n");
          scanf("%s",motdepasse);
        }
        else{
          printf("l'identifiant n'est pas bon\n\n");
        }
    break;
    /* The coding that allows you to log in by entering the login and password*/
    case 2:
    printf("il faut se rendre dans un autre site\n\n");
    break;
    }

  
printf("Bienvenu %s\n\n", identifiant);
printf("voici les livres que vous avez emprunté:\n\n");
  /* Welcome and show the borrowed books*/


int action;
char livre_action[100];

printf("Quelle action voulez vous faire ?\n\n");
printf("1. Emprunter un livre.\n");
printf("2. Rendre un livre.\n");
printf("Se déconnecter\n");
/* Asks the user what action they want to take between borrowing a book, returning one or logging out*/

scanf("%d", &action);
  

switch(action){
  case 1:
  printf("Lequel voulez vous emprunté ?\n");
  scanf("%s", livre_action);
  break;
  case 2:
  printf("Lequel voulez vous rendre ?\n");
  scanf("%s", livre_action);
  break;
  case 3:
  printf("Voulez vous vraiment vous déconnecter ?\n");
  // Ask for details according to the chosen action
}
    
  
  return 0;
}