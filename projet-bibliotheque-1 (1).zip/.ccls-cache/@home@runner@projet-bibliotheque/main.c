#include <stdio.h>
#include<stdlib.h>
#include<string.h>


typedef struct{
char titre[100];
char auteur[100];
int numero_id;
char cathégorie[100];
}Livre;


typedef struct{
char login[100];
char mdp[100];
char role[100];
}Utilisateur;

int main() {

  FILE* F;

  F=fopen
  
  return 0;
}